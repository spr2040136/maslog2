package com.example.configuration

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.configuration.databinding.ActivityIndividualBinding

class IndividualActivity : AppCompatActivity() {
    private lateinit var binding: ActivityIndividualBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIndividualBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener { finish() }
    }
}